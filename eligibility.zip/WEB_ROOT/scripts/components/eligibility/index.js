define(function(require) {
    'use strict';
    var angular = require('angular');
    require('components/eligibility/controllers/index');
    require('components/eligibility/directives/index');
});