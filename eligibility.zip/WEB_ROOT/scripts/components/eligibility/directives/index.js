define(function(require) {
    'use strict';
    require('components/eligibility/directives/elidata');
});