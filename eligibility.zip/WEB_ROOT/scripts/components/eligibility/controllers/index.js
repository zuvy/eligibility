define(function(require) {
    'use strict';
    require('components/eligibility/controllers/elictrl');
    require('components/eligibility/controllers/pdctrl');
    require('components/eligibility/controllers/listctrl');
});